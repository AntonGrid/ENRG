use anchor_lang::prelude::*;

/// Solana blockchain adapter.
///
/// Real SPL Token integration will be implemented
/// after Protocol Core is complete.
pub fn placeholder() -> Result<()> {
    Ok(())
}
