use anchor_lang::prelude::*;

/// Oracle Registry.
///
/// Stores the set of trusted Oracle identities
/// authorized to submit verified reports
/// to the ENRG Protocol.
#[account]
pub struct OracleRegistry {
    /// Registry authority (DAO / Governance).
    pub authority: Pubkey,

    /// Trusted Oracle identities.
    pub oracles: Vec<Pubkey>,
}

impl OracleRegistry {
    /// Maximum number of trusted Oracles.
    pub const MAX_ORACLES: usize = 100;

    pub const LEN: usize =
        32 +
        4 + Self::MAX_ORACLES * 32;

    /// Returns true if Oracle is trusted.
    pub fn contains(
        &self,
        oracle: &Pubkey,
    ) -> bool {
        self.oracles.contains(oracle)
    }
}
